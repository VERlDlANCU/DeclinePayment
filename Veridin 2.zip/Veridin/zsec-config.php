<?php

//config for zsec do not change anything
$add = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]"; //server checker DO NOT CAHNGE
$keyy = "NTU2Njg4NTU"; //zsec confirmation key
$api = "Sohlution4uJ0KWGJHI7EAC"; //zsec api

$zsec_site = "https://Zsec.youdontcare.xyz/";

// on off zsec
$zsec_p = "off";

?>
