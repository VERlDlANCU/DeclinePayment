<?php

$settings = array(
	"chat_id"		=> "",	// Chat ID Of You
	"bot_url"		=> "bot",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
);
return $settings;

?>